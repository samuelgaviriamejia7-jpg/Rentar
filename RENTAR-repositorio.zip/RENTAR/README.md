# RentAr

Plataforma web de alquiler de vehículos entre particulares.

Proyecto de Media Técnica en Programación — Universidad Pontificia Bolivariana, Medellín, 2026.

## Equipo

| Integrante | Módulos |
|---|---|
| Samuel Gaviria Mejía | Reservas, vehículos, pagos y puntos, perfil, administración y núcleo |
| Juan José Álvarez Cardona | Catálogo y página de inicio |
| Juan José Castrillón Valencia | Historial de reservas y manuales |
| Saúl Benítez | Registro, inicio de sesión y sedes de recogida |

## Estructura

| Carpeta | Contenido |
|---|---|
| `FASE 1 - ANTEPROYECTO` | Documentación de la etapa de anteproyecto |
| `FASE 2 - PRODUCTO` | Código fuente de la plataforma y base de datos |
| `FASE 3 - PRESENTACIÓN` | Material de la socialización |

## Tecnologías

PHP 8, MySQL con PDO y consultas preparadas, HTML, CSS y JavaScript. Corre sobre XAMPP.
La librería GD de PHP genera el comprobante de reserva como imagen desde el servidor.

## Cómo montarlo

1. Copia `FASE 2 - PRODUCTO/codigo` dentro de `C:\xampp\htdocs\` y renómbrala `rentar`.
2. Inicia Apache y MySQL desde el panel de XAMPP.
3. Entra a `http://localhost/phpmyadmin` e importa `FASE 2 - PRODUCTO/rentar_bd.sql`.
4. Abre `http://localhost/rentar`.

Cuenta de administrador para pruebas: `admin@rentar.com` / `admin123`

## Qué hace

- Catálogo con filtros por tipo, precio, transmisión y disponibilidad por fechas.
- Publicación de vehículos con aprobación de un administrador.
- Reservas por días, con cambio de fechas o sede e historial de cada modificación.
- Pasarela de pago simulada. Del número de la tarjeta solo se guardan los últimos cuatro dígitos.
- Comprobante de reserva descargable en JPG, generado en el servidor.
- Puntos: 20 por día alquilado, cada punto equivale a $100 de descuento.
- Panel de administración: verificación de usuarios y aprobación de publicaciones.

RentAr retiene el 25% de cada alquiler. El resto queda para el dueño del vehículo.
