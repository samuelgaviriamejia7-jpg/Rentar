# Fase 3 — Presentación

Material usado en la socialización del proyecto.

| Archivo | Descripción |
|---|---|
| `RentAr-pantallas.pptx` | Las 36 pantallas de la plataforma |

