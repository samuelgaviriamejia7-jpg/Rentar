# Fase 2 — Producto

Código fuente de la plataforma RentAr y su base de datos.

## Contenido

| Archivo | Descripción |
|---|---|
| `codigo/` | Aplicación web completa |
| `rentar_bd.sql` | Script de creación de la base de datos |

## Cómo montarlo

1. Descomprime o copia la carpeta `codigo` dentro de `C:\xampp\htdocs\` y renómbrala `rentar`.
2. Inicia Apache y MySQL desde el panel de XAMPP.
3. Entra a `http://localhost/phpmyadmin` e importa `rentar_bd.sql`.
4. Abre `http://localhost/rentar`.

Cuenta de administrador para pruebas: `admin@rentar.com` / `admin123`

## Organización del código

| Carpeta | Contenido |
|---|---|
| `conexion/` | Conexión PDO a la base de datos |
| `funciones/` | Funciones compartidas, cabecera, pie e iconos |
| `modulos/` | Catálogo, reservas, pagos, puntos, perfil y comprobantes |
| `admin/` | Panel de administración: verificación y aprobaciones |
| `registros/` | Registro, inicio y cierre de sesión |
| `css/` | Hoja de estilos |
| `img/` | Imágenes del sitio |
| `fuentes/` | Tipografía usada para generar el comprobante |
| `uploads/` | Fotos de perfil y de vehículos subidas por los usuarios |

## Funcionalidades

- Registro con dos roles: arrendatario y arrendador, intercambiables desde el perfil
- Verificación de usuarios por parte de un administrador
- Publicación de vehículos sujeta a aprobación
- Catálogo con filtros por tipo, precio, transmisión y disponibilidad por fechas
- Reserva con sedes, fechas y cálculo automático del total
- Comprobante en JPG generado desde PHP
- Pasarela de pago de prueba con validación de tarjeta
- Puntos RentAr Rewards aplicables como descuento
- Calificaciones, favoritos, notificaciones e historial de cambios
- Panel de ingresos para arrendadores
- Alquiler con opción de compra mediante abonos
- Modo claro y oscuro
