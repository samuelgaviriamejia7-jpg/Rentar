# Fase 1 — Anteproyecto

Documentos y evidencias de la etapa de anteproyecto.

Pendiente de subir:

- Documento del anteproyecto
- Planteamiento del problema y justificación
- Objetivos general y específicos
- Estado del arte
- Alcance del proyecto
- Metodología de trabajo
- Cronograma
